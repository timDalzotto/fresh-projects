package teammates.storage.entity;

/**
 * Base class for all entities persisted to the Datastore.
 */
public abstract class BaseEntity { // NOPMD
}
