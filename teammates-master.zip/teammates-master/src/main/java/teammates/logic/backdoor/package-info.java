/**
 * Provides a mechanism for the test driver and client scripts to access data.
 */
package teammates.logic.backdoor;
