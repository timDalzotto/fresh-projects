/**
 * Contains infrastructure and helpers needed for retrying arbitrary code.
 */
package teammates.common.util.retry;
