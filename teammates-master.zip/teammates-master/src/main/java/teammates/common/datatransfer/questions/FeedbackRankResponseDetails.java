package teammates.common.datatransfer.questions;

public abstract class FeedbackRankResponseDetails extends FeedbackResponseDetails {
    public FeedbackRankResponseDetails(FeedbackQuestionType questionType) {
        super(questionType);
    }
}
