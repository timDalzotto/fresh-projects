package teammates.common.datatransfer;

/**
 * The basic search result bundle object.
 */
public class SearchResultBundle {

    public int numberOfResults;

    protected SearchResultBundle() {
        // prevents instantiation; to be instantiated as children classes
    }

}
