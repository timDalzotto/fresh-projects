/**
 * Contains servlets and action classes for user-invoked actions.
 */
package teammates.ui.controller;
