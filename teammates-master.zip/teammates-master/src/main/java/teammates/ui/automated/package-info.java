/**
 * Contains servlets and action classes for automated actions (i.e. cron jobs, task queue workers).
 */
package teammates.ui.automated;
