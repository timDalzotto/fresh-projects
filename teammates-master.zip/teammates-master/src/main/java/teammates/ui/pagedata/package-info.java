/**
 * Contains view model classes for JSP files.
 */
package teammates.ui.pagedata;
